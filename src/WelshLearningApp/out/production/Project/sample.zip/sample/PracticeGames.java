package sample;

import java.lang.reflect.Array;
import java.util.*;


public class PracticeGames {
//    private Scanner scan = new Scanner(System.in);
    Dictionary dictionary = new Dictionary();
    SortedMap<String, Word> engDict = dictionary.getDictEnglishMap();
    //SortedMap<String, Word> welDict = dictionary.getDictWelshMap();


    public void resetDict(Dictionary d) {
        dictionary = d;
        engDict = dictionary.getDictEnglishMap();
        //welDict = dictionary.getDictWelshMap();
    }

//    public void guessCard() {
////        resetDict(dict);
//        SortedMap<String, Word> engDict = dictionary.getDictEnglishMap();
//        int score = 0;
//        String checkAnswer;
//        String exit = "";
//        HashSet<String> quest = new HashSet<>();
//
//        Word n = null;
//        String ran = null;
//        String ran1 = null;
//        String ran2 = null;
//        String ran3 = null;
//        Question question = new Question();
//        Random random = new Random();
////        System.out.println(engDict.keySet());
//        Object[] num = dictionary.dictEnglishMap.keySet().toArray();
//
////        System.out.println(Arrays.toString(num));
//        do {
//            int counter = 0;
//            do {
//                Object key = num[new Random().nextInt(num.length)];
//                quest.add(dictionary.dictEnglishMap.get(key).getWelshWord());
////            System.out.println(englishMap.get(key).getEnglishWord());
//
//                n = dictionary.dictEnglishMap.get(key);
//                counter++;
//            } while (counter < 4);
//
////                 System.out.println(Arrays.toString(choice.toArray()));
//            ArrayList<String> choice = new ArrayList<>(quest);
////
//            ran = choice.get(random.nextInt(4));
//            if (choice.contains(ran)) {
//                choice.remove(ran);
//                quest.remove(ran);
//            }
//            ran1 = choice.get(random.nextInt(3));
//            if (choice.contains(ran1)) {
//                choice.remove(ran1);
//                quest.remove(ran1);
//            }
//            ran2 = choice.get(random.nextInt(2));
//            if (choice.contains(ran2)) {
//                choice.remove(ran2);
//                quest.remove(ran2);
//            }
//            ran3 = choice.get(random.nextInt(1));
//            if (choice.contains(ran3)) {
//                choice.remove(ran3);
//                quest.remove(ran3);
//            }
////        }
//            question = new Question(n.getEnglishWord(), ran, ran1, ran2, ran3,"","", n.getWelshWord());
//            System.out.println("Current score = " + score);
//            System.out.println("Need 10 points to win");
//            System.out.println("Question is " + question.getWordToAnswer());
//            System.out.println("First choice - " + question.getOption1());
//            System.out.println("Second choice - " + question.getOption2());
//            System.out.println("Third choice - " + question.getOption3());
//            System.out.println("Forth choice - " + question.getOption4());
//            System.out.println("The Answer is - " + question.getAnswer());
//            System.out.println("Please Q to exit the game");
//            System.out.println("Please choice numbers between 1 - 4");
//            checkAnswer = scan.nextLine().toUpperCase();
//            switch (checkAnswer) {
//                case "1":
//                    if (question.getOption1().equals(n.getWelshWord())) {
//                        System.out.println("Correct Answer");
//                        score++;
//                    } else {
//                        System.out.println("Incorrect Answer");
//                    }
//
//                    break;
//                case "2":
//                    if (question.getOption2().equals(n.getWelshWord())) {
//                        System.out.println("Correct Answer");
//                        score++;
//                    } else {
//                        System.out.println("Incorrect Answer");
//                    }
//                    break;
//                case "3":
//                    if (question.getOption3().equals(n.getWelshWord())) {
//                        System.out.println("Correct Answer");
//                        score++;
//                    } else {
//                        System.out.println("Incorrect Answer");
//                    }
//                    break;
//                case "4":
//                    if (question.getOption4().equals(n.getWelshWord())) {
//                        System.out.println("Correct Answer");
//                        score++;
//                    } else {
//                        System.out.println("Incorrect Answer");
//                    }
//                    break;
//                case "Q":
//                    exit = "Q";
//                default:
//                    System.out.println("Please choose number between 1 to 4 only!");
//            }
//        } while (!(exit.equals("Q") || score == 10));
//
//    }
//
//    protected void flashCards() {
////        System.out.println("hi");
//        Object[] randNum = dictionary.dictEnglishMap.keySet().toArray();
////        do {
//        int counter = 0;
//        do {
//            Object key = randNum[new Random().nextInt(randNum.length)];
//
//            System.out.println("English word - " + dictionary.dictEnglishMap.get(key).getEnglishWord() + "\tWelsh word - " + dictionary.dictEnglishMap.get(key).getWelshWord());
//            counter++;
//        } while (counter < 4);
//    }
//
//    protected void enterWord() {
//        System.out.println("enterWord");
//        String ans;
//        Random rand = new Random();
////        System.out.println(engDict.keySet());
//        Object[] num = dictionary.dictEnglishMap.keySet().toArray();
//        int total = 2;
//        int count = 0;
//        do {
//            boolean repeat = true;
//            Object key = num[new Random().nextInt(num.length)];
//            do {
//                Word w = dictionary.dictEnglishMap.get(key);
//                String s = w.getEnglishWord().trim();
//                System.out.println("What is the Welsh word for '" + s + "'?");
//                System.out.println(w.getWelshWord().trim());
//                ans = scan.nextLine().toLowerCase().trim();
//                if (ans.equals(w.getWelshWord())) {
//                    System.out.println("Correct Answer");
//                    count++;
//                    repeat = false;
//                } else {
//                    System.out.println("Wrong Answer");
//                }
//            } while (repeat);
//        } while (count <= total);
//        System.out.println("Finished");
//    }

    protected Word getWord() {
        Object[] num = dictionary.dictEnglishMap.keySet().toArray();
        Object key = num[new Random().nextInt(num.length)];
        return dictionary.getDictEnglishMap().get(key);
    }


    // jumbled words

    // storing marks
    int correct = 0;

    protected ArrayList<Word> GetWords(int amount) {

        // create arraylist
        ArrayList<Word> words = new ArrayList<>();

        // gets random words from dictionary
        Object[] num = dictionary.dictEnglishMap.keySet().toArray();
        Object key = num[new Random().nextInt(num.length)];

        // loop for amount of words wanted
        for(int i = 0; i <= amount; i++){
            key = num[new Random().nextInt(num.length)];
            words.add(dictionary.getDictEnglishMap().get(key));
        }
        return words;
    }

    //shuffle words into a random order
    protected ArrayList<Word> jumbledWordsShuffleWords(ArrayList<Word> words, int amount){
        // creates a list to store the welsh value of words
        List<Word> shuffledWords = new ArrayList<>();
        for(int i = 0; i < amount; i++){
            shuffledWords.add(words.get(i));
        }

        // shuffles words for a random order
        Collections.shuffle(shuffledWords);

        // puts words into an array
        ArrayList<Word> shuffledArray = new ArrayList<>(shuffledWords);
        return shuffledArray;
    }

    protected String jumbledWordsMark(ArrayList<Word> words, Word word1,Word word2, Word word3, Word word4) {
        correct = 0;
        if(words.get(0) == word1){
            correct++;
        }
        if(words.get(1) == word2){
            correct++;
        }
        if(words.get(2) == word3){
            correct++;
        }
        if(words.get(3) == word4){
            correct++;
        }
        return "You got " + correct + " answers correct";
    }

}
