package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class AddWordsController extends DictionaryController implements Initializable{

    @FXML private TextField englishWordTextField;
    @FXML private TextField welshWordTextField ;
    @FXML private ChoiceBox<String> wordTypeChoiceBox = new ChoiceBox<>();
    public static ObservableList<String> wordTypes = FXCollections.observableArrayList("nm","nf","verb","other");
    @FXML private Text confirmationText;
    @FXML private Button addButton;
    private boolean added;

    public void newWordButtonPushed(){

        if(added){
            dialog.close();
        }else{
        if(wordTypeChoiceBox.getValue().equals("verb")){
            englishWordTextField.setText("To "+ englishWordTextField.getText());
        }
        Word newWord = new Word(englishWordTextField.getText(),
                welshWordTextField.getText(),
                wordTypeChoiceBox.getValue());

//        if(wordTypeChoiceBox.getValue().equals("verb")){
//            englishWordTextField.setText("to "+ englishWordTextField.getText());
//        }


        if (words.contains(newWord)){
            System.out.println("word already exists in the dictionary");
            confirmationText.setText("word already exists in the dictionary");
        }else{
//            if(wordTypeChoiceBox.getValue().equals("verb")){
//                englishWordTextField.setText("to "+ englishWordTextField.getText());
//            }
        words.add(newWord);
            System.out.println(newWord+ " word added");
            confirmationText.setText("word added");
            addButton.setText("Close");
            userinterface.save(words, wordsMy);
//        wordsMy.add(newWord);
            //System.out.println(words);
            added = true;
        }

        }
       // tableViewDictionary.setItems(words);
    }


    @Override
    public void initialize (URL location, ResourceBundle resources) {

        wordTypeChoiceBox.setItems(wordTypes);
        confirmationText.setText("");
        addButton.setText("Add Word");
        added = false;
    }

}
