package sample;
import org.json.simple.JSONObject;
import java.util.Iterator;
import java.util.Objects;


public class Word {
    // variables
    private String englishWord;
    private String welshWord;
    private String wordType;

    // constructor
    public Word(String english, String welsh, String type) {
        englishWord = english;
        welshWord = welsh;
        wordType = type;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Word word = (Word) o;
        return Objects.equals(englishWord, word.englishWord) &&
                Objects.equals(welshWord, word.welshWord) &&
                Objects.equals(wordType, word.wordType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(englishWord, welshWord, wordType);
    }

    public Word() {
    }


    public String getEnglishWord() {
        return englishWord;
    }


    public String getWelshWord() {
        return welshWord;
    }

    public String getWordType() {
        return wordType;
    }

    public void load(Iterator<JSONObject> iterator) {

        JSONObject object = iterator.next();
        englishWord = (String) object.get("english");
        welshWord = (String) object.get("welsh");
        wordType = (String) object.get("wordType");

    }

    public void save(JSONObject object, String welsh, String wordType, String english) {

        object.put("welsh", welsh);
        object.put("wordType", wordType);
        object.put("english", english);
    }

}
