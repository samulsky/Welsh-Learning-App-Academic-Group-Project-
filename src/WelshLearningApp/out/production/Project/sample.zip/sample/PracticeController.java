package sample;

import javafx.application.Platform;

import java.io.IOException;

public class PracticeController {

    public void goFlashcards() throws Exception{
        UI.showFlashCards();
    }

    public void goGuessWord() throws Exception{
        UI.showGuessWord();
    }

    public void goTranslateWord() throws Exception{
        UI.showTranslateWord();
    }

    public void goMatchWord() throws Exception{
        UI.showMatchWord();
    }

    public void goDictionary() throws IOException {
        UI.backToDictionary();
    }

    public void Exit() {

        Platform.exit();
        System.exit(0);
    }

    public void goBack() throws IOException {
        UI.showMyWords();
    }
}
