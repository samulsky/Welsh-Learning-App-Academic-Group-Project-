package sample;

import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class FlashcardsController implements Initializable {

    public static Dictionary dictionary = new Dictionary();
    public static PracticeGames practiceGames = new PracticeGames();
    public Word word;
    public double progressBarCounter;

    public Button nextWord;
    public Button flashCard;
    public ProgressBar progressBar = new ProgressBar(0);

    public void goMenu() throws IOException {
        //UI.backToMenu();
    }

    public void Exit() {
        Platform.exit();
        System.exit(0);
    }

    public void goBack() throws IOException {
        UI.showPractice();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        dictionary.loadDictList("Assets/practiceList.json");
        practiceGames.resetDict(dictionary);
        progressBarCounter = 0;
        newFlashCard();
    }

    public void newFlashCard(){
        word = practiceGames.getWord();
        flashCard.setText(word.getEnglishWord());
    }

    public void clickFlashCard(){
        if(flashCard.getText() == word.getEnglishWord()){
            flashCard.setText(word.getWelshWord());
        }else{
            flashCard.setText(word.getEnglishWord());
        }
    }

    public void setNextWord() throws IOException{
        if(progressBarCounter != 20){
            progressBarCounter += 1;
            newFlashCard();
            updateProgressBar();
        }else{
            UI.showPractice();
        }
    }

    public void updateProgressBar(){
        progressBar.setProgress(progressBarCounter/20);
    }
}
