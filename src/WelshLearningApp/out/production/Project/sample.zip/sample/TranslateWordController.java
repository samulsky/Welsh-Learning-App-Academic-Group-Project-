package sample;

import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class TranslateWordController implements Initializable {


    public Button nextWordButton;
    public Button answerButton;
    public ProgressBar progressBar;
    public Text wordLabel;
    public TextField userAnswer;

    public static Dictionary dictionary = new Dictionary();
    public static PracticeGames practiceGames = new PracticeGames();
    public Word word;
    public double progressBarCounter;
    public int correct;


    public void goMenu() throws IOException {
   // UI.backToMenu();
    }

    public void Exit() {
        Platform.exit();
        System.exit(0);
    }

    public void goBack() throws IOException {
        UI.showPractice();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        correct = 0;
        progressBarCounter = 0;
        dictionary.loadDictList("Assets/practiceList.json");
        practiceGames.resetDict(dictionary);
        word = practiceGames.getWord();
        wordLabel.setText(word.getEnglishWord());
        userAnswer.setText("");
    }

    public void pass(){
        word = practiceGames.getWord();
        wordLabel.setText(word.getEnglishWord());
        userAnswer.setText("");
        progressBarCounter += 1;
        updateProgressBar();
    }

    public void mark(){
        if(userAnswer.getText().toLowerCase() == word.getWelshWord().toLowerCase()){
            correct++;
        }
        if(progressBarCounter < 20){
            pass();
        }else{
            wordLabel.setText("you got " + correct + " questions right");
        }
    }

    public void updateProgressBar(){
        progressBar.setProgress(progressBarCounter/20);
    }
}
