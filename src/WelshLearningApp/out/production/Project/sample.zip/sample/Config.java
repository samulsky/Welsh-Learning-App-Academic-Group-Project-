package sample;
import java.util.Scanner;

public class Config {
    private Scanner scan = new Scanner(System.in);
    Dictionary dictionary = new Dictionary();
    PracticeGames practiceGames = new PracticeGames();
    MyWords myWords = new MyWords();

    public void runApp() {
        String dictionaryJson = "Assets/dictionary.json";
        String practiceListJson = "Assets/practiceList.json";
        dictionary.loadDictList(dictionaryJson);
        myWords.loadPracList(practiceListJson);

//        mainMenu();
    }

//    protected void mainMenu() {
//
//        String check;
//        do {
//            System.out.println("Please select one of the options");
//            System.out.println("1 - Dictionary");
//            System.out.println("2 - Learn");
//            System.out.println("3 - PracticeGames");
//            System.out.println("Q - go back");
//            check = scan.nextLine().toUpperCase();
//
//            switch (check) {
//                case "1":
//                    dictionaryMenu();
//                    break;
//                case "2":
//                    dictionary.learnMenu();
//                    break;
//                case "3":
//                    practiceGames.resetDict(dictionary);
//                    practiceGamesMenu();
//                    break;
//                case "Q":
//                    check = "Q";
////                    dictionary.saveDictList("Assets/dictionary.json");
//
//            }
//        } while (!(check.equals("Q")));
//    }
//
//    private void dictionaryMenu() {
//
////        String input;
////        do {
////
////            System.out.println("Please select one of the options");
////            System.out.println("1 - Search in English");
////            System.out.println("2 - Search in Welsh");
////            System.out.println("3 - Add a word to dict");
////            System.out.println("Q - go back");
////            input = scan.nextLine().toUpperCase();
////            switch (input) {
////                case "1":
////
////                    dictionary.translateEnglish();
////
////                    break;
////                case "2":
////                    dictionary.translateWelsh();
////                    break;
////                case "3":
////                    dictionary.addWordtoDictionary();
////                    break;
////                case "Q":
////                    input = "Q";
////            }
////        } while (!(input.equals("Q")));
//    }
//
//    //
//    private void practiceGamesMenu() {
//        String input;
//        do {
//
//            System.out.println("Please select one of the options");
//            System.out.println("1 - Practice game");
//            System.out.println("2 - Flash cards");
//            System.out.println("3 - Translate");
//            System.out.println("4 - JumbledWord");
//            System.out.println("Q - go back");
//            input = scan.nextLine().toUpperCase();
//            switch (input) {
//                case "1":
//                    practiceGames.guessCard();
//                    break;
//                case "2":
//                    practiceGames.flashCards();
//                    break;
//                case "3":
//                    practiceGames.enterWord();
//                    break;
//                case "4":
//                   // practiceGames.getWord(1);
//                    break;
//                case "Q":
//                    input = "Q";
//            }
//        } while (!(input.equals("Q")));
//    }


}
