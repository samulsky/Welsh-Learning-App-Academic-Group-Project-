package sample;
import javafx.collections.ObservableList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Dictionary {
    private Scanner scan = new Scanner(System.in);
    protected SortedMap<String, Word> dictEnglishMap = new TreeMap<>();
    //protected SortedMap<String, Word> dictWelshMap = new TreeMap<>();

    public Dictionary() {
    }

//    protected void addWordtoDictionary() {
//        System.out.println("Please enter the word to enter in the dict");
//        System.out.println("Please enter the English word");
//        String eng = scan.nextLine();
//        System.out.println("Please enter the Welsh word");
//        String wel = scan.nextLine();
//        System.out.println("Please enter the wordType");
//        String type = scan.nextLine();
//        Word addWord = new Word(eng, wel, type);
//        dictEnglishMap.put(eng, addWord);
//        dictWelshMap.put(wel, addWord);
//    }
//
//    protected void translateWelsh() {
//        String wel;
//        Word tempWord;
//        do {
//            System.out.println("Rhowch air i chwilio");
//            System.out.println("neu ysgrifennwch Q");
//            wel = scan.nextLine().strip().toLowerCase();
//            if (!wel.equals("q")) {
//                if (dictWelshMap.containsKey(wel)) {
//                    tempWord = dictWelshMap.get(wel);
//                    System.out.println(tempWord.getEnglishWord());
//                }
//            }
//        }
//        while (!(wel.equals("q")));
//    }
//
//    protected String translateEnglish(String eng) {
////        String eng;
//        Word tempVar = null;
//        do {
//
////            System.out.println("Enter word to search");
////            System.out.println("or exit writing Q");
////            eng = scan.nextLine().strip().toLowerCase();
//            if (!eng.equals("q")) {
////            System.out.println(searchEnglish(eng));
//                if (dictEnglishMap.containsKey(eng)) {
//                    tempVar = dictEnglishMap.get(eng);
//                    System.out.println(tempVar.getWelshWord());
//                }
//
//            }
//        }
//        while (!(eng.equals("q")));
//        return tempVar.getWelshWord();
//    }

//    protected void printEnglish() {
//        int count = 0;
//        ArrayList<Integer> saveList = new ArrayList<>();
//
//        Set<Map.Entry<String, Word>> s = englishMap.entrySet();
//
//        // Using iterator in SortedMap
//        Iterator<Map.Entry<String, Word>> i = s.iterator();
//
//        // Traversing map. Note that the traversal
//        // produced sorted (by keys) output .
//        while (i.hasNext()) {
//            Map.Entry<String, Word> m = i.next();
//
//            String key = m.getKey();
//            Word value = m.getValue();
//
//            System.out.println("English Word : " + key +
//                    "  Welsh Word : " + value.getWelshWord());
//            saveList.add(count);
//
//        }
//        System.out.println(saveList.size());
//    }
protected ArrayList<Word> displayWords(SortedMap<String, Word> map) {
    int count = 0;
    ArrayList<Integer> saveList = new ArrayList<>();
    ArrayList<Word> wordList = new ArrayList<>();

    Set s = map.entrySet();

    // Using iterator in SortedMap
    Iterator i = s.iterator();

    // Traversing map. Note that the traversal
    // produced sorted (by keys) output .
    while (i.hasNext()) {
        Map.Entry m = (Map.Entry) i.next();
        wordList.add((Word) m.getValue());
;

    }
//    System.out.println(saveList.size());
    return wordList;
}

//    protected Word save(){
//        String save = scan.nextLine().trim();
//        for (int i = 0; i <englishMap.size() ; i++) {
//            if
//
//
//        }
//    }

//    protected void learnMenu() {
//        String exit = "";
//        Object[] num = dictEnglishMap.keySet().toArray();
////        do {
//        int counter = 0;
//        do {
//            Object key = num[new Random().nextInt(num.length)];
//
//            System.out.println("English word - " + dictEnglishMap.get(key).getEnglishWord() + "\tWelsh word - " + dictEnglishMap.get(key).getWelshWord());
//            counter++;
//        } while (counter < 4);
//
//    }

    protected void loadDictList(String fileName) {
        loadList(fileName, dictEnglishMap/*, dictWelshMap*/);

    }
        protected void loadList(String fileName, SortedMap<String, Word> englishMap/*, SortedMap<String, Word> welshMap*/){
        JSONParser parser = new JSONParser();
        try {
            Object fileObj = parser.parse(new FileReader(fileName));
            JSONArray obj = (JSONArray) fileObj;
            Iterator<JSONObject> iterator = obj.iterator();
            //goes through all the objects

                    while (iterator.hasNext()) {
                        Word loadWord = null;
                        loadWord = new Word();
                        loadWord.load(iterator);
                        englishMap.put(loadWord.getEnglishWord(), loadWord);
                        //welshMap.put(loadWord.getWelshWord(), loadWord);
                    }
                    System.out.println("words loaded");



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
//
    }
//    protected void saveDictList(String fileName){
//        saveList(fileName, dictEnglishMap, dictWelshMap);
//    }

    void saveList(String fileName, ObservableList<Word> dictWords) {
        JSONObject object = new JSONObject();
        // creates a string that will be used to write the json file
        String output = "[";
        // puts all the objects into the string
        for(int counter = 0;counter < dictWords.size();counter++){
            object.put("welsh",dictWords.get(counter).getWelshWord());
            object.put("wordType",dictWords.get(counter).getWordType());
            object.put("english",dictWords.get(counter).getEnglishWord());
            // checks if there is another word after the current word and if it needs a ',' at the end of the object in the string
            if (counter != dictWords.size()-1){
                output = output + object.toString()+",";
            }else{
                output = output + object.toString();
            }
        }
        output = output + "]";
        // writes the string to the new file
        try(FileWriter file = new FileWriter(fileName)){
            file.write(output);
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//    void saveList(String fileName, SortedMap<String, Word> englishMap, SortedMap<String, Word> welshMap) {
//        JSONObject object = new JSONObject();
////        words = binaryTree.save();
//
//        // creates a string that will be used to write the json file
//        String output = "[";
//        // puts all the objects into the string
//        int counter = 0;
//        for (Map.Entry<String, Word> entry : englishMap.entrySet()) {
//            Word word = new Word();
////            assert false;
//            word.save(object, entry.getValue().getWelshWord(), entry.getValue().getWordType(), entry.getKey());
//            counter++;
//            if (counter != englishMap.size() - 1) {
//                output = output + object.toString() + ",";
//            } else {
//                output = output + object.toString();
//            }
//        }
//        output = output + "]";
//        // writes the string to the new file
//        try (FileWriter file = new FileWriter(fileName)) {
//            file.write(output);
//            file.flush();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//    }

    public SortedMap<String, Word> getDictEnglishMap() {
        return dictEnglishMap;
    }

//    public SortedMap<String, Word> getDictWelshMap() {
//        return dictWelshMap;
//    }


}

