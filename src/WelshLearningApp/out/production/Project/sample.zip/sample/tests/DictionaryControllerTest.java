package sample.tests;

import static org.junit.jupiter.api.Assertions.*;

class DictionaryControllerTest {

    @org.junit.jupiter.api.Test
    void goMenu() {
    }

    @org.junit.jupiter.api.Test
    void exit() {
    }

    @org.junit.jupiter.api.Test
    void initialize() {
    }
}