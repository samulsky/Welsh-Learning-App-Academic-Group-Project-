package sample;

import sample.Dictionary;
import sample.PracticeGames;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class PracticeGamesTest {

    @Test
    public void resetDictTest(){
        Dictionary dictionary = new Dictionary();
        PracticeGames practice = new PracticeGames();
        dictionary.loadDictList("Assets/dictionary.json");
        practice.resetDict(dictionary);
        Assertions.assertEquals(dictionary,practice.dictionary);
        Assertions.assertEquals(dictionary.getDictEnglishMap(),practice.dictionary.getDictEnglishMap());
        //Assertions.assertEquals(dictionary.getDictWelshMap(),practice.dictionary.getDictWelshMap());
    }

    @Test
    public void testGetWordsFunction(){
        // creates a dictionary
        Dictionary dictionary = new Dictionary();

        // creates 3 words
        Word word1 = new Word("abbey","abaty","nm");
        Word word2 = new Word("about to","ar fin","other");
        Word word3 = new Word("above","uwchben","other");

        // put words into dictionary
        dictionary.dictEnglishMap.put("abbey", word1);
        dictionary.dictEnglishMap.put("about to", word2);
        dictionary.dictEnglishMap.put("above", word3);
//        dictionary.dictWelshMap.put("abaty",word1);
//        dictionary.dictWelshMap.put("ar fin",word1);
//        dictionary.dictWelshMap.put("uwchben",word1);

        // creates a PracticeGame object and adds the dictionary
        PracticeGames practiceGames = new PracticeGames();
        practiceGames.resetDict(dictionary);

        // gets an ArrayList of 3 random words from dictionary
        ArrayList<Word> words = new ArrayList<>();
        words = practiceGames.GetWords(3);

        // boolean to check if a word is found
        boolean found;

        // counter until all words are found
        int counter = 0;

        // checks if 3 random words have been selected
        for(int i = 0; i<3;i++){
            found = false;
            while(!found){
                if(word1==words.get(i)){
                    found = true;
                }else if(word2==words.get(i)){
                    found = true;
                }else if(word3==words.get(i)){
                    found = true;
                }
            }
            counter++;
        }

        // checks if 3 random words were found
        Assertions.assertEquals(3,counter);
    }


    @Test
    public void testIfGetWordsFunctionOutputsRandomWords(){
        // creates a dictionary
        Dictionary dictionary = new Dictionary();

        // creates 3 words
        Word word1 = new Word("abbey","abaty","nm");
        Word word2 = new Word("about to","ar fin","other");
        Word word3 = new Word("above","uwchben","other");

        // put words into dictionary
        dictionary.dictEnglishMap.put("abbey", word1);
        dictionary.dictEnglishMap.put("about to", word2);
        dictionary.dictEnglishMap.put("above", word3);
//        dictionary.dictWelshMap.put("abaty",word1);
//        dictionary.dictWelshMap.put("ar fin",word1);
//        dictionary.dictWelshMap.put("uwchben",word1);

        // creates a PracticeGame object and adds the dictionary
        PracticeGames practiceGames = new PracticeGames();
        practiceGames.resetDict(dictionary);

        // gets 2 ArrayList of 3 random words from dictionary
        ArrayList<Word> words1 = new ArrayList<>();
        ArrayList<Word> words2 = new ArrayList<>();
        words1 = practiceGames.GetWords(3);


        // tests if the produced ArrayLists are different
        Assertions.assertNotEquals(words1,words2);
    }

    @Test
    void testGetWordFunction(){
        // creates a dictionary
        Dictionary dictionary = new Dictionary();

        // creates 3 words
        Word word1 = new Word("abbey","abaty","nm");
        Word word2 = new Word("about to","ar fin","other");
        Word word3 = new Word("above","uwchben","other");

        // put words into dictionary
        dictionary.dictEnglishMap.put("abbey", word1);
        dictionary.dictEnglishMap.put("about to", word2);
        dictionary.dictEnglishMap.put("above", word3);
//        dictionary.dictWelshMap.put("abaty",word1);
//        dictionary.dictWelshMap.put("ar fin",word1);
//        dictionary.dictWelshMap.put("uwchben",word1);

        // creates a PracticeGame object and adds the dictionary
        PracticeGames practiceGames = new PracticeGames();
        practiceGames.resetDict(dictionary);

        // creates and gets a random word 2 times;
        Word word4 = new Word();
        Word word5 = new Word();
        word4 = practiceGames.getWord();
        word5 = practiceGames.getWord();

        // could randomly select the same word
        // this is unlikely if your list is large but necessary if you only have a small number of words and need more than you have
        while(word4.equals(word5)){
            word5 = practiceGames.getWord();
        }

        // tests if the words are random
        Assertions.assertNotEquals(word4,word5);
    }
}
