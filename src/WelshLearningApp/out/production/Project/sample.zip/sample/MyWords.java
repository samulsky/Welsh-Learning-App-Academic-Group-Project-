package sample;

import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;

public class MyWords extends Dictionary{
//    private Scanner scan = new Scanner(System.in);
    SortedMap<String, Word> pracEnglishMap = new TreeMap<>();
    SortedMap<String, Word> pracWelshMap = new TreeMap<>();
//    MyWords practiceList = new MyWords();

//    public MyWords()

    protected void loadPracList(String fileName){ loadList(fileName, pracEnglishMap/*, pracWelshMap*/);
    }

}
