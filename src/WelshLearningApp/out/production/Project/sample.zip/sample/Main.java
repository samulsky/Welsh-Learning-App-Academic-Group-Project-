package sample;
import javafx.application.Application;

public class Main {


        public static void main(String[] args) throws Exception {

            Config configuration = new Config();
            UI userInterface = new UI();
//            Application.launch(UI.class, args);
//            configuration.runApp();
            Application.launch(UI.class, args);

        }


}
