package sample;

import sample.Dictionary;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class DictionaryTest {


    // test fails but the function is never used
//    @Test
//    void testTranslateEnglishFunction() {
//    // creates a dictionary
//    Dictionary dictionary = new Dictionary();
//
//    // creates word
//    Word word1 = new Word("abbey", "abaty", "nm");
//
//    // put word into dictionary
//    dictionary.englishMap.put("abbey", word1);
//    dictionary.welshMap.put("abaty", word1);
//
//    //test translation to welsh
//    Assertions.assertEquals("abaty",dictionary.translateEnglish("abbey"));
//    }

    @Test
    void testDisplayWordsFunction(){
        // creates a dictionary
        Dictionary dictionary = new Dictionary();

        // creates 3 words
        Word word1 = new Word("abbey","abaty","nm");
        Word word2 = new Word("about to","ar fin","other");
        Word word3 = new Word("above","uwchben","other");

        // put words into dictionary
        dictionary.dictEnglishMap.put("abbey", word1);
        dictionary.dictEnglishMap.put("about to", word2);
        dictionary.dictEnglishMap.put("above", word3);
//        dictionary.dictWelshMap.put("abaty",word1);
//        dictionary.dictWelshMap.put("ar fin",word1);
//        dictionary.dictWelshMap.put("uwchben",word1);

        // puts word into ArrayList
        ArrayList<Word> words = new ArrayList<>();
        words.add(word1);
        words.add(word2);
        words.add(word3);

        // tests to see if all the words are output
        Assertions.assertEquals(words, dictionary.displayWords(dictionary.dictEnglishMap));

    }
}
