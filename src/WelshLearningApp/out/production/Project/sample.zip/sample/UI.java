package sample;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.SortedMap;

public class UI extends Application {

    private Stage primaryStage;
    private static BorderPane mainLayout;
    public static Dictionary dictionary = new Dictionary();
    public static Config configuration = new Config();
    public static MyWords pracList = new MyWords();
    public  ArrayList<Word> dictionaryWords = new ArrayList<>();
    public  ArrayList<Word> pracWords = new ArrayList<>();
    @Override
    public void start(Stage primaryStage) throws Exception{
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Welsh Learning App");
        configuration.runApp();
        resetDict(configuration.dictionary);
        resetPracList(configuration.myWords);
        loadWordsToDict();
        loadWordsToPrac();
        showDictionary();
//        configuration.mainMenu();
    }



    public static void backToDictionary() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Dictionary.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

   private void showDictionary() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Dictionary.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    public void loadWordsToDict(){
        dictionaryWords =  dictionary.displayWords(dictionary.dictEnglishMap);
    }
    public void loadWordsToPrac(){
        pracWords =  pracList.displayWords(pracList.pracEnglishMap);
    }


    public static void showPractice() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("Practice.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void showMyWords() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("MyWords.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void showFlashCards() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("Flashcards.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void showGuessWord() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("GuessWord.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void showTranslateWord() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("TranslateWord.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void showMatchWord() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(UI.class.getResource("MatchWords.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
//    public static void resetDict(Dictionary d) {
//        dictionary = d;
//        engDict = dictionary.getDictEnglishMap();
//        welDict = dictionary.getDictWelshMap();
//    }
    public static void resetDict(Dictionary d) {
        dictionary = d;
//        engDict = dictionary.getDictEnglishMap();
//        welDict = dictionary.getDictWelshMap();
    }
    public static void resetPracList(MyWords myWords) {
        pracList = myWords;

    }
    public void save(ObservableList<Word> dictList, ObservableList<Word> pracList){
        configuration.dictionary.saveList("Assets/dictionary.json", dictList);
        configuration.dictionary.saveList("Assets/practiceList.json", pracList);

    }

//    public static void main(String[] args) {
//        launch(args);
//    }
}
