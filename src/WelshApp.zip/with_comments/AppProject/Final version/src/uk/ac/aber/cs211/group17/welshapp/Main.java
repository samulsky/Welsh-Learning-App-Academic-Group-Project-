package uk.ac.aber.cs211.group17.welshapp;
import javafx.application.Application;
import javafx.fxml.FXML;


public class Main {


        public static void main(String[] args) throws Exception {

            Application.launch(UI.class, args);

        }


}
