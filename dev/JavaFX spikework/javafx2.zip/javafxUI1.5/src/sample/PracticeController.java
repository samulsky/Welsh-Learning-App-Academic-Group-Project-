package sample;

import javafx.application.Platform;

import java.io.IOException;

public class PracticeController {

    public void goFlashcards() throws Exception{
        Main.showFlashCards();
    }

    public void goGuessWord() throws Exception{
        Main.showGuessWord();
    }

    public void goMenu() throws IOException {
        Main.backToMenu();
    }

    public void Exit() {
        Platform.exit();
        System.exit(0);
    }

    public void goBack() throws IOException {
        Main.showMyWords();
    }
}
