package sample;


import javafx.application.Platform;
import java.io.IOException;


public class MenuController {


    public void goToLearn() throws IOException {
        Main.showLearn();
    }

    public void goMenu() throws IOException {
        Main.backToMenu();
    }

    public void goToDictionary() throws IOException {
        Main.showDictionary();
    }

    public void goToOptions() throws IOException {
        Main.showOptions();
    }

   /* public void goToPractice() throws IOException {
        Main.showPractice();
    }*/

    public void goToMyWords() throws IOException {
        Main.showMyWords();
    }

    public void Exit() throws Exception {
        Platform.exit();
        System.exit(0);
    }




}