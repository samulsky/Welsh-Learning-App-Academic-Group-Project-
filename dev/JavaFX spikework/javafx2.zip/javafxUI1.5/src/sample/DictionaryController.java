package sample;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class DictionaryController implements Initializable {



    @FXML public TableView<Word> tableViewDictionary;
    @FXML public TableColumn<Word,String> englishWord;
    @FXML public TableColumn<Word,String> welshWord;
    @FXML public TableColumn<Word,String> wordType;
    @FXML public TableColumn<Word, Void> colBtn;
    @FXML private TextField searchField;
    public static ObservableList<Word> words = FXCollections.observableArrayList();
    public static ObservableList<Word> wordsMy = FXCollections.observableArrayList();
    final static Stage dialog = new Stage();



    public void goMenu() throws IOException {
        Main.backToMenu();
    }

    private void searchForWords() {

        FilteredList<Word> filteredList = new FilteredList<>(words, b -> true);

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredList.setPredicate(word -> {

                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }

                String lowerCaseFilter = newValue.toLowerCase();

                if (word.getEnglishWord().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (word.getWelshWord().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                } else if (word.getWordType().indexOf(lowerCaseFilter) != -1)
                    return true;
                else
                    return false;
            });
        });

        SortedList<Word> sortedList = new SortedList<>(filteredList);
        sortedList.comparatorProperty().bind(tableViewDictionary.comparatorProperty());
        tableViewDictionary.setItems(sortedList);
    }


    @FXML
    private void addWordsWindow() throws IOException {


        AnchorPane dialogVbox;
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("AddWords.fxml"));
        dialogVbox = loader.load();
        Scene dialogScene = new Scene(dialogVbox);
        dialog.setScene(dialogScene);
        dialog.show();
    }

    private void addButtons(){



        Callback<TableColumn<Word,Void>, TableCell<Word,Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
                    @Override
                    public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                        final TableCell<Word,Void> cell = new TableCell<Word,Void>(){
                            final Button btn = new Button("+");

                            @Override
                            public void updateItem(Void item, boolean empty){
                                super.updateItem(item,empty);
                                if (empty){
                                    setGraphic(null);
                                    setText(null);
                                }else {
                                    btn.setOnAction(event -> {
                                        Word word = getTableView().getItems().get(getIndex());
                                       // System.out.println(word.getEnglishWord()+word.getWelshWord()+word.getWordType());

                                        wordsMy.add(new Word(word.getEnglishWord(), word.getWelshWord(), word.getWordType()));





                                    });
                                    setGraphic(btn);
                                    setText(null);
                                }
                            }
                        };
                        return cell;
                    }
                };
        colBtn.setCellFactory(cellFactory);
        //tableViewDictionary.getColumns().add(colBtn);    // crashes program keeping just in case


    }

    public void Exit() {
        Platform.exit();
        System.exit(0);
    }


    private ObservableList<Word> getWords(){


        words.add(new Word("abbey ","abaty ","nm"));
        words.add(new Word("about to ","ar fin ","other"));
        words.add(new Word("above ","uwchben ","other"));
        words.add(new Word("abbey1 ","abaty1 ","nm"));
        words.add(new Word("about to1 ","ar fin1 ","other"));
        words.add(new Word("above1 ","uwchben1 ","other"));
        words.add(new Word("abbey2 ","abaty2 ","nm"));
        words.add(new Word("about to2 ","ar fin2 ","other"));
        words.add(new Word("above2 ","uwchben2 ","other"));

        return words;
    }



    @Override
    public void initialize(URL location, ResourceBundle resources) {

        englishWord.setCellValueFactory(new PropertyValueFactory<>("englishWord"));
        welshWord.setCellValueFactory(new PropertyValueFactory<>("welshWord"));
        wordType.setCellValueFactory(new PropertyValueFactory<>("wordType"));

        tableViewDictionary.setItems(getWords());
        addButtons();
        searchForWords();
    }
}



