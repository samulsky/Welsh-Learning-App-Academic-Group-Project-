package sample;

import javafx.application.Platform;

import java.io.IOException;

public class FlashcardsController {


    public void goMenu() throws IOException {
        Main.backToMenu();
    }

    public void Exit() {
        Platform.exit();
        System.exit(0);
    }

    public void goBack() throws IOException {
        Main.showPractice();
    }


}
