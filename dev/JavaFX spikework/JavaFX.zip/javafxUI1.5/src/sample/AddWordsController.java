package sample;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ResourceBundle;

public class AddWordsController extends DictionaryController implements Initializable{

    @FXML private TextField englishWordTextField;
    @FXML private TextField welshWordTextField ;
    @FXML private TextField wordTypeTextField;


    public void newWordButtonPushed(){
        Word newWord = new Word(englishWordTextField.getText(),
                welshWordTextField.getText(),
                wordTypeTextField.getText());

        if (words.contains(newWord)){
            System.out.println("word already exists in the dictionary");
        }else{
        words.add(newWord);
        wordsMy.add(newWord);
        dialog.close();
            //System.out.println(words);

        }
       // tableViewDictionary.setItems(words);
    }


    @Override
    public void initialize (URL location, ResourceBundle resources) {
    }

}
