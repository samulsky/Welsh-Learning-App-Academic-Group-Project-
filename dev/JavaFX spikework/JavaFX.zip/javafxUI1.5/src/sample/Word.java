package sample;

import javafx.beans.property.SimpleStringProperty;

public class Word {
    private String englishWord;
    private String welshWord;
    private String wordType;

    public String getEnglishWord() {
        return englishWord;
    }

    public void setEnglishWord(String englishWord) {
        this.englishWord = englishWord;
    }

    public String getWelshWord() {
        return welshWord;
    }

    public void setWelshWord(String welshWord) {
        this.welshWord = welshWord;
    }

    public String getWordType() {
        return wordType;
    }

    public void setWordType(String wordType) {
        this.wordType = wordType;
    }

    public Word(String englishWord, String welshWord, String wordType) {
        this.englishWord = englishWord;
        this.welshWord = welshWord;
        this.wordType = wordType;
    }
}
