package sample;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LearnController implements Initializable {

    @FXML private TableView<Word> tableViewLearn;
    @FXML private TableColumn<Word,String> englishWordLearn;
    @FXML private TableColumn<Word,String> welshWordLearn;
    @FXML private TableColumn<Word,String> wordTypeLearn;
    @FXML private TableColumn<Word, Void> colBtnLearn;
    private ObservableList<Word> words2 = FXCollections.observableArrayList();
    @FXML private TextField searchFieldLearn;



    public void goMenu() throws IOException {
        Main.backToMenu();
    }

    public void Exit() throws Exception {
        Platform.exit();
        System.exit(0);
    }

//    private void searchForWords() {
//
//        FilteredList<Word> filteredList = new FilteredList<>(words2, b -> true);
//
//        searchFieldLearn.textProperty().addListener((observable, oldValue, newValue) -> {
//            filteredList.setPredicate(word -> {
//
//                if (newValue == null || newValue.isEmpty()) {
//                    return true;
//                }
//
//                String lowerCaseFilter = newValue.toLowerCase();
//
//                if (word.getEnglishWord().toLowerCase().indexOf(lowerCaseFilter) != -1) {
//                    return true;
//                } else if (word.getWelshWord().toLowerCase().indexOf(lowerCaseFilter) != -1) {
//                    return true;
//                } else if (word.getWordType().indexOf(lowerCaseFilter) != -1)
//                    return true;
//                else
//                    return false;
//            });
//        });
//
//        SortedList<Word> sortedList = new SortedList<>(filteredList);
//        sortedList.comparatorProperty().bind(tableViewLearn.comparatorProperty());
//        tableViewLearn.setItems(sortedList);
//    }

    private void addButtons(){

        // DOES WORK ??????

        Callback<TableColumn<Word,Void>, TableCell<Word,Void>> cellFactory
                = new Callback<TableColumn<Word, Void>, TableCell<Word, Void>>() {
            @Override
            public TableCell<Word, Void> call(TableColumn<Word, Void> param) {
                final TableCell<Word,Void> cell = new TableCell<Word,Void>(){
                    final Button btn = new Button("+");

                    @Override
                    public void updateItem(Void item, boolean empty){
                        super.updateItem(item,empty);
                        if (empty){
                            setGraphic(null);
                            setText(null);
                        }else {
                            btn.setOnAction(event -> {
                                Word word = getTableView().getItems().get(getIndex());
                                System.out.println(word.getEnglishWord()+word.getWelshWord()+word.getWordType());
                            });
                            setGraphic(btn);
                            setText(null);
                        }
                    }
                };
                return cell;
            }
        };
        colBtnLearn.setCellFactory(cellFactory);
        //tableView.getColumns().add(colBtn);


    }

    private ObservableList<Word> getWords(){

        words2.add(new Word("abbey ","abaty ","nm"));
        words2.add(new Word("about to ","ar fin ","other"));
        words2.add(new Word("above ","uwchben ","other"));
        words2.add(new Word("abbey1 ","abaty1 ","nm"));
        words2.add(new Word("about to1 ","ar fin1 ","other"));
        words2.add(new Word("above1 ","uwchben1 ","other"));
        words2.add(new Word("abbey2 ","abaty2 ","nm"));
        words2.add(new Word("about to2 ","ar fin2 ","other"));
        words2.add(new Word("above2 ","uwchben2 ","other"));

        return words2;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        englishWordLearn.setCellValueFactory(new PropertyValueFactory<>("englishWord"));
        welshWordLearn.setCellValueFactory(new PropertyValueFactory<>("welshWord"));
        wordTypeLearn.setCellValueFactory(new PropertyValueFactory<>("wordType"));

        tableViewLearn.setItems(getWords());
        addButtons();
       // searchForWords();
    }
}



