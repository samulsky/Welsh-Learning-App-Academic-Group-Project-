package sample;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.io.IOException;

public class Main extends Application {

    private Stage primaryStage;
    private static BorderPane mainLayout;


    @Override
    public void start(Stage primaryStage) throws Exception{
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Welsh Learning App");

        showMenu();
    }

    private void showMenu() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Menu.fxml"));
        mainLayout = loader.load();
        Scene scene = new Scene(mainLayout);
        primaryStage.setScene(scene);
        primaryStage.show();

    }

     public static void showLearn() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Learn.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
    public static void backToMenu() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Menu.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
    public static void showDictionary() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Dictionary.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
    public static void showPractice() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Practice.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
    public static void showOptions() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("Options.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }
    public static void showMyWords() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("MyWords.fxml"));
        BorderPane sc = loader.load();
        mainLayout.setCenter(sc);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
